package com.udacity.catpoint.security;

import com.udacity.catpoint.SecurityService;
import com.udacity.catpoint.data.*;
import com.udacity.catpoint.image.service.ImageServiceInterface;
import com.udacity.catpoint.application.StatusListener;
import org.easymock.EasyMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.easymock.EasyMockExtension;
import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Assertions;


@ExtendWith(EasyMockExtension.class)
class SecurityServiceTest {

    private SecurityService securityService;
    Sensor sensor1 = new Sensor("Door", SensorType.DOOR);
    Sensor sensor2 = new Sensor("Window", SensorType.WINDOW);
    Sensor sensor3 = new Sensor("Motion", SensorType.MOTION);
    private ImageServiceInterface imageServiceInterface;
    private SecurityRepository securityRepository;
    private StatusListener statusListener;
    Set<Sensor> sensors = new HashSet<>();

    @BeforeEach
    void init() {
        sensors.add(sensor1);
        sensors.add(sensor2);
        sensors.add(sensor3);

        imageServiceInterface = EasyMock.createMock(ImageServiceInterface.class);
        securityRepository = EasyMock.createMock(SecurityRepository.class);

        securityService = new SecurityService(securityRepository, imageServiceInterface);
    }
    //test1
    @Test
    void putSystemIntoPendingAlarmStatusWhenArmedAndSensorActivated() {
        // Arrange
        ArmingStatus armingStatus = ArmingStatus.ARMED_AWAY;

        // Specify expected calls
        EasyMock.expect(securityRepository.getArmingStatus()).andReturn(armingStatus);
        EasyMock.expect(securityRepository.getAlarmStatus()).andReturn(AlarmStatus.NO_ALARM);

        securityService.changeSensorActivationStatus(sensor1, true);
        securityRepository.setAlarmStatus(AlarmStatus.PENDING_ALARM);

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Act
        securityService.changeSensorActivationStatus(sensor1, true);

        // Verify
        EasyMock.verify(securityRepository, imageServiceInterface);
    }
//test2
    @ParameterizedTest
    @EnumSource(value = ArmingStatus.class, names = {"ARMED_AWAY", "ARMED_HOME"})
    public void setAlarmStatusToAlarmWhenArmedAndSensorActivatedAndPendingAlarm(ArmingStatus armingStatus) {
        // Arrange
        EasyMock.expect(securityRepository.getArmingStatus()).andReturn(armingStatus).anyTimes();
        EasyMock.expect(securityRepository.getAlarmStatus()).andReturn(AlarmStatus.PENDING_ALARM).anyTimes();

        // Expectations for changeSensorActivationStatus
        securityService.changeSensorActivationStatus(sensor1, true);
        EasyMock.expectLastCall();

        // Expectation for setAlarmStatus
        securityRepository.setAlarmStatus(AlarmStatus.ALARM);
        EasyMock.expectLastCall();

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Act
        securityService.changeSensorActivationStatus(sensor1, true);

        // Verify
        EasyMock.verify(securityRepository, imageServiceInterface);
    }
    //test3
    @Test
    public void returnToNoAlarmStateWhenPendingAlarmAndAllSensorsInactive() {
        // Arrange
        EasyMock.expect(securityRepository.getArmingStatus()).andReturn(ArmingStatus.ARMED_HOME).anyTimes();
        EasyMock.expect(securityRepository.getAlarmStatus()).andReturn(AlarmStatus.PENDING_ALARM).anyTimes();

        // Expectations for changeSensorActivationStatus
        securityService.changeSensorActivationStatus(sensor1, true);
        EasyMock.expectLastCall();
        securityService.changeSensorActivationStatus(sensor1, false);
        EasyMock.expectLastCall();

        // Expectation for setAlarmStatus
        securityRepository.setAlarmStatus(AlarmStatus.NO_ALARM);
        EasyMock.expectLastCall();

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Act
        securityService.changeSensorActivationStatus(sensor1, true);
        securityService.changeSensorActivationStatus(sensor1, false);

        // Verify
        EasyMock.verify(securityRepository, imageServiceInterface);
    }
    // Test4
    @ParameterizedTest
    @ValueSource(booleans = {true, false})
    public void changeInSensorStateShouldNotAffectAlarmStateWhenAlarmIsActive(boolean sensorStatus) {
        // Arrange
        EasyMock.expect(securityRepository.getAlarmStatus()).andReturn(AlarmStatus.ALARM).anyTimes();

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Act
        securityService.changeSensorActivationStatus(sensor1, sensorStatus);

        // Verify
        EasyMock.verify(securityRepository, imageServiceInterface);
    }

    // Test5
    @Test
    void changeStatusToAlarmStateWhenSensorActivatedAndSystemIsPendingState() {
        // Arrange
        EasyMock.expect(securityRepository.getAlarmStatus()).andReturn(AlarmStatus.PENDING_ALARM).anyTimes();

        // Set up the sensor as active
        sensor1.setActive(true);

        // Expectation for setAlarmStatus
        securityRepository.setAlarmStatus(AlarmStatus.ALARM);
        EasyMock.expectLastCall().times(1);

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Act
        securityService.changeSensorActivationStatus(sensor1, true);

        // Verify
        EasyMock.verify(securityRepository, imageServiceInterface);
    }

    // Test6
    @ParameterizedTest
    @EnumSource(value = AlarmStatus.class, names = {"ALARM", "PENDING_ALARM", "NO_ALARM"})
    public void noChangesToAlarmStateWhenSensorDeactivatedWhileInactive(AlarmStatus alarmStatus) {
        // Arrange
        EasyMock.expect(securityRepository.getAlarmStatus()).andReturn(AlarmStatus.PENDING_ALARM).anyTimes();

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Act: Deactivate the sensor while it's already inactive
        securityService.changeSensorActivationStatus(sensor1, false);

        // Verify: Verify that the alarm status remains unchanged
        EasyMock.verify(securityRepository, imageServiceInterface);
    }
    //test7
     @Test
    public void putSystemIntoAlarmStatusWhenIdentifiesCatArmedHome() {
        // Arrange
        EasyMock.expect(securityRepository.getArmingStatus()).andReturn(ArmingStatus.ARMED_HOME).anyTimes();
        EasyMock.expect(imageServiceInterface.imageContainsCat(EasyMock.isA(BufferedImage.class), EasyMock.anyFloat())).andReturn(true).anyTimes();

        // Expectation for setAlarmStatus
        securityRepository.setAlarmStatus(AlarmStatus.ALARM);
        EasyMock.expectLastCall().times(1);

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Act: Process the image
        securityService.processImage(EasyMock.mock(BufferedImage.class));

        // Verify
        EasyMock.verify(securityRepository, imageServiceInterface);
    }

    // Test8
    @Test
    public void changeStatusToNoAlarmWhenSensorsNotActiveAndIdentifiesImageNotContainCat() {
        // Arrange
        EasyMock.expect(securityRepository.getSensors()).andReturn(sensors).anyTimes();
        EasyMock.expect(imageServiceInterface.imageContainsCat(EasyMock.isA(BufferedImage.class), EasyMock.anyFloat())).andReturn(true).anyTimes();

        // Expectation for setAlarmStatus
        securityRepository.setAlarmStatus(AlarmStatus.NO_ALARM);
        EasyMock.expectLastCall().times(1);

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Act: Process the image
        securityService.processImage(EasyMock.mock(BufferedImage.class));
        // Verify
        EasyMock.verify(securityRepository, imageServiceInterface);
    }

    // Test9
    @Test
    public void setAlarmStatusToNoAlarmWhenSystemIsDisarmed() {
        // Arrange: Set the system to disarmed state
        securityService.setArmingStatus(ArmingStatus.DISARMED);

        // Expectation for setAlarmStatus
        securityRepository.setAlarmStatus(AlarmStatus.NO_ALARM);
        EasyMock.expectLastCall().times(1);

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Verify
        EasyMock.verify(securityRepository, imageServiceInterface);
    }

    // Test10
    @ParameterizedTest
    @EnumSource(value = ArmingStatus.class, names = {"ARMED_AWAY", "ARMED_HOME"})
    public void resetAllSensorsToInactiveWhenSystemIsArmed(ArmingStatus armingStatus) {
        // Arrange
        Set<Sensor> sensorAll = new HashSet<>();
        sensorAll.add(sensor1);
        sensorAll.add(sensor2);
        sensorAll.add(sensor3);

        sensor1.setActive(true);
        sensor2.setActive(true);
        sensor3.setActive(true);

        EasyMock.expect(securityRepository.getSensors()).andReturn(sensorAll).anyTimes();
        EasyMock.expect(securityRepository.getAlarmStatus()).andReturn(AlarmStatus.PENDING_ALARM).anyTimes();

        // Expectation for setArmingStatus
        securityService.setArmingStatus(armingStatus);
        EasyMock.expectLastCall().times(1);

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Act
        securityService.setArmingStatus(armingStatus);

        // Verify
       
        Assertions.assertTrue(securityRepository.getSensors().stream().noneMatch(Sensor::getActive));
        EasyMock.verify(securityRepository, imageServiceInterface);
    }

    // Test11
    @Test
    public void setAlarmStatusToAlarmWhenSystemIsArmedHomeWhileCameraShowsCat() {
        // Arrange
        EasyMock.expect(securityRepository.getArmingStatus()).andReturn(ArmingStatus.ARMED_HOME).anyTimes();
        EasyMock.expect(imageServiceInterface.imageContainsCat(EasyMock.isA(BufferedImage.class), EasyMock.anyFloat())).andReturn(true).anyTimes();

        // Expectation for setAlarmStatus
        securityRepository.setAlarmStatus(AlarmStatus.ALARM);
        EasyMock.expectLastCall().times(1);

        // Replay
        EasyMock.replay(securityRepository, imageServiceInterface);

        // Act: Process the image
        securityService.processImage(EasyMock.mock(BufferedImage.class));

        // Verify
        EasyMock.verify(securityRepository, imageServiceInterface);
    }
    @Test
    public void addAndRemoveStatusListenerSuccess() {
        // Arrange
        StatusListener statusListener = EasyMock.createMock(StatusListener.class);

        // Expectation for addStatusListener
        securityService.addStatusListener(statusListener);
        EasyMock.expectLastCall().times(1);

        // Expectation for removeStatusListener
        securityService.removeStatusListener(statusListener);
        EasyMock.expectLastCall().times(1);

        // Replay
        EasyMock.replay(securityService, statusListener);

        // Act
        securityService.addStatusListener(statusListener);
        securityService.removeStatusListener(statusListener);

        // Verify
        EasyMock.verify(securityService, statusListener);
    }

    @Test
    public void addAndRemoveSensorSuccess() {
        // Arrange
        Sensor sensor1 = EasyMock.createMock(Sensor.class);

        // Expectation for addSensor
        securityService.addSensor(sensor1);
        EasyMock.expectLastCall().times(1);

        // Expectation for removeSensor
        securityService.removeSensor(sensor1);
        EasyMock.expectLastCall().times(1);

        // Replay
        EasyMock.replay(securityService, sensor1);

        // Act
        securityService.addSensor(sensor1);
        securityService.removeSensor(sensor1);

        // Verify
        EasyMock.verify(securityService, sensor1);
    }

    @Test
    public void getAlarmStatusSuccess() {
        // Arrange
        EasyMock.expect(securityRepository.getAlarmStatus()).andReturn(AlarmStatus.NO_ALARM).anyTimes();

        // Replay
        EasyMock.replay(securityRepository);

        // Act
        securityService.getAlarmStatus();

        // Verify
        EasyMock.verify(securityRepository);
    }

    @Test
    public void setAlarmStatusIsAlarmWhenCatDetectedAndArmingStatusIsArmedHome() {
        // Arrange
        EasyMock.expect(securityRepository.getArmingStatus()).andReturn(ArmingStatus.ARMED_HOME).anyTimes();
        securityService.setCatDetected(true);

        // Expectation for setAlarmStatus
        securityRepository.setAlarmStatus(AlarmStatus.ALARM);
        EasyMock.expectLastCall().times(1);

        // Replay
        EasyMock.replay(securityRepository);

        // Act
        securityService.setArmingStatus(ArmingStatus.ARMED_HOME);

        // Verify
        EasyMock.verify(securityRepository);
    }

    @Test
    public void setAlarmStatusIsPendingAlarmWhenSensorIsInactivatedWhileAlreadyActive() {
        // Arrange
        sensor1.setActive(true);
        EasyMock.expect(securityRepository.getAlarmStatus()).andReturn(AlarmStatus.ALARM).anyTimes();
        EasyMock.expect(securityRepository.getArmingStatus()).andReturn(ArmingStatus.DISARMED).anyTimes();

        // Expectation for changeSensorActivationStatus
        securityService.changeSensorActivationStatus(sensor1, false);
        EasyMock.expectLastCall().times(1);

        // Expectation for setAlarmStatus
        securityRepository.setAlarmStatus(AlarmStatus.PENDING_ALARM);
        EasyMock.expectLastCall().times(1);

        // Replay
        EasyMock.replay(securityRepository, sensor1);

        // Act
        securityService.changeSensorActivationStatus(sensor1, false);

        // Verify
        EasyMock.verify(securityRepository, sensor1);
    }

}

