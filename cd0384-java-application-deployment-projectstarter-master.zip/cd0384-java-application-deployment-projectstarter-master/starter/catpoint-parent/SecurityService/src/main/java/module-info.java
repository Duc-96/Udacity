module SecurityService {
    requires ImageService;
    requires com.google.gson;
    requires com.google.common;
    requires java.desktop;
    requires miglayout;
    requires java.prefs;
    opens com.udacity.catpoint.data to com.google.gson;
}